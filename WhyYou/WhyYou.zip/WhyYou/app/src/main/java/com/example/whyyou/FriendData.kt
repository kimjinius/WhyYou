package com.example.whyyou

data class FriendData (
        val name: String
        )