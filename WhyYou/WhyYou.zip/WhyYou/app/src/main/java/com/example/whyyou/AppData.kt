package com.example.whyyou

data class AppData (
        val title : String,
        val friendName : String,
        val date : String,
        val time : String
        )